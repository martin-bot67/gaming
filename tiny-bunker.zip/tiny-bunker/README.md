# Tiny Bunker

ES modules need a local server:

    npx serve .

or

    python3 -m http.server 8000

then open the printed address.

js/models.js: data and shared state
js/systems.js: game logic, saving
js/renderer.js: canvas drawing
js/ui.js: panels and input
js/main.js: game loop
